import java.util.*;

/**
 * 
 */
public class Response {

    /**
     * Default constructor
     */
    public Response() {
    }

    /**
     * 
     */
    public Integer StudentId;

    /**
     * 
     */
    public Integer QuestionId;

    /**
     * 
     */
    public Char SelectedChoice;

}
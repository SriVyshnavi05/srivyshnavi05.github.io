
import java.util.*;

/**
 * 
 */
public class Test paper {

    /**
     * Default constructor
     */
    public Test paper() {
    }

    /**
     * 
     */
    public Integer TestId;

    /**
     * 
     */
    public Char Question;

    /**
     * 
     */
    public Char Choice1;

    /**
     * 
     */
    public Char Choice2;

    /**
     * 
     */
    public Char Choice3;

    /**
     * 
     */
    public Char Choice4;

}
import java.util.*;

/**
 * 
 */
public class Test {

    /**
     * Default constructor
     */
    public Test() {
    }

    /**
     * 
     */
    public Integer TestId;

    /**
     * 
     */
    public Char TestName;

    /**
     * 
     */
    public Float Duration;

    /**
     * 
     */
    public Char StartTime;

    /**
     * 
     */
    public Integer NoOfQuestions;

}
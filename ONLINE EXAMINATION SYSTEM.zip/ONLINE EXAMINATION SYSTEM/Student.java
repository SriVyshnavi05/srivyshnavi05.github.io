
import java.util.*;

/**
 * 
 */
public class Student {

    /**
     * Default constructor
     */
    public Student() {
    }

    /**
     * 
     */
    public Integer Id;

    /**
     * 
     */
    public Char Name;

    /**
     * 
     */
    public Char Address;

    /**
     * 
     */
    public Integer contactNo;

    /**
     * 
     */
    public void GiveExam() {
        // TODO implement here
    }

    /**
     * 
     */
    public void CheckResult() {
        // TODO implement here
    }

}

import java.util.*;

/**
 * 
 */
public class Examiner {

    /**
     * Default constructor
     */
    public Examiner() {
    }

    /**
     * 
     */
    public Integer Id;

    /**
     * 
     */
    public Char Name;

    /**
     * 
     */
    public void PrepareTestPaper() {
        // TODO implement here
    }

    /**
     * 
     */
    public void ModifyTestPaper() {
        // TODO implement here
    }

    /**
     * 
     */
    public void DeclareResult() {
        // TODO implement here
    }

    /**
     * 
     */
    public void CheckCopies() {
        // TODO implement here
    }

}
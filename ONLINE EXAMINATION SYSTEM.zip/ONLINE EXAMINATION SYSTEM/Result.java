
import java.util.*;

/**
 * 
 */
public class Result {

    /**
     * Default constructor
     */
    public Result() {
    }

    /**
     * 
     */
    public Integer StudentId;

    /**
     * 
     */
    public Float Marks;

    /**
     * 
     */
    public Char Grade;

}
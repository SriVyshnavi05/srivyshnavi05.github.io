import java.util.*;
/**
 * 
 */
public class Admin {

    /**
     * Default constructor
     */
    public Admin() {
    }

    /**
     * @param email
     */
    public void SendInvite(void email) {
        // TODO implement here
        cout<<"Enter your email id:"<<endl;
        cin>>email;
        
    }

    /**
     * 
     */
    public void SendResult() {
        // TODO implement here
    }

}